﻿using DAL_Bank;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL_Banl
{
    public class Transection
    {
        public bool DoLogin(string Act_number, string Password)
        {
            using (var context = new BanKContext())
            {
                var account = from a in context.BanKs.ToList()
                              where (a.Act_Number == Act_number && a.Password == Password)
                              select a;
                foreach (var a in account)
                {
                    if (a != null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                return false;

            }
        }

        public BanK FetchOptions(string Act_number, string Password)
        {
            using (var context = new BanKContext())
            {
                var account = from a in context.BanKs.ToList()
                              where (a.Act_Number == Act_number && a.Password == Password)
                              select a;
                foreach (var a in account)
                {
                    return a;
                }
                return null;

            }
        }
        public double Deposit(string Act_number, double Amount)
        {
            using (var context = new BanKContext())
            {
                var account = context.BanKs.SingleOrDefault(s => s.Act_Number == Act_number);
                if (account != null)
                {
                    account.Balance += Amount;
                    context.SaveChanges();
                    BanK ob = new BanK();
                    ob.Act_Number = Act_number;
                    ob.Balance = account.Balance;
                    return ob.Balance;
                }
                else
                {
                    return 0.00;
                }
            }

        }
        public double Withdraw(string Act_number, double Amount)
        {
            using (var context = new BanKContext())
            {
                var account = context.BanKs.SingleOrDefault(s => s.Act_Number == Act_number);
                if (account != null)
                {
                    account.Balance -= Amount;
                    context.SaveChanges();
                    BanK ob = new BanK();
                    ob.Act_Number = Act_number;
                    ob.Balance = account.Balance;
                    return ob.Balance;
                }
                else
                {
                    return 0.00;
                }
            }

        }
    }
        
}
